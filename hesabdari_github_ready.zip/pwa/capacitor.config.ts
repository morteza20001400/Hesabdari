import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hesabdari.project',
  appName: 'حسابداری پروژه',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
